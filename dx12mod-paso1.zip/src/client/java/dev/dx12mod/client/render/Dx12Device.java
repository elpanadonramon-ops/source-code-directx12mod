package dev.dx12mod.client.render;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.CompiledRenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.shaders.ShaderSource;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.textures.AddressMode;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuSampler;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import dev.dx12mod.Dx12Mod;
import dev.dx12mod.client.Dx12Mode;
import dev.dx12mod.client.Dx12Native;
import dev.dx12mod.client.shader.ShaderTranslator;
import org.jspecify.annotations.Nullable;
import org.lwjgl.glfw.GLFWNativeWin32;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.platform.DestFactor;
import com.mojang.blaze3d.platform.SourceFactor;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormatElement;

import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.OptionalDouble;
import java.util.function.Supplier;

/**
 * Paso 5: GpuDevice propio con texturas reales. Crea el swapchain DX12 sobre la ventana de Minecraft;
 * recursos y comandos son stubs (ver Dx12Resources). No toca OpenGL en absoluto.
 */
public final class Dx12Device implements GpuDevice {
	private final CommandEncoder encoder = new Dx12CommandEncoder();
	private final String adapter;
	private int pipelines;
	private int shadersOk;
	private int shadersFailed;
	private int nativeOk;
	private int nativeFailed;
	private boolean translatorBroken;
	private final ShaderSource defaultShaderSource;
	private final Map<RenderPipeline, Dx12Resources.Pipeline> compiled = new HashMap<>();
	static Dx12Device instance;
	private static final boolean NO_CULL = Dx12Mode.flag("nocull");
	private static final boolean FLIP_CULL = Dx12Mode.flag("flipcull");
	private static final boolean NO_DEPTH = Dx12Mode.flag("nodepth");

	public Dx12Device(long glfwWindow, ShaderSource defaultShaderSource) {
		this.defaultShaderSource = defaultShaderSource;
		instance = this;
		long hwnd = GLFWNativeWin32.glfwGetWin32Window(glfwWindow);
		if (hwnd == 0L) {
			throw new IllegalStateException("No se pudo obtener el HWND de la ventana");
		}
		Dx12Native.setInflight(Dx12Mode.flag("serial") ? 1 : (Dx12Mode.flag("triple") ? 3 : 2));
		if (!Dx12Native.init(hwnd)) {
			throw new IllegalStateException("Fallo iniciando DX12: " + Dx12Native.lastError());
		}
		this.adapter = Dx12Native.adapterName();
		Dx12Mod.LOGGER.info("[DX12] Dispositivo DirectX 12 creado en: {}", adapter);
		StringBuilder flags = new StringBuilder();
		for (String f : new String[] {"nocull", "flipcull", "nodepth", "nomip", "trace", "novsync", "serial", "triple"}) {
			if (Dx12Mode.flag(f)) flags.append(f).append(' ');
		}
		if (flags.length() > 0) Dx12Mod.LOGGER.info("[DX12] Banderas de depuracion activas: {}", flags.toString().trim());
	}

	@Override public CommandEncoder createCommandEncoder() { return encoder; }

	@Override
	public GpuSampler createSampler(AddressMode u, AddressMode v, FilterMode min, FilterMode mag, int aniso, OptionalDouble lod) {
		return new Dx12Resources.Sampler(u, v, min, mag, aniso, lod);
	}

	@Override
	public GpuTexture createTexture(@Nullable Supplier<String> label, int usage, TextureFormat format, int w, int h, int layers, int mips) {
		return new Dx12Resources.Texture(usage, label == null ? null : label.get(), format, w, h, layers, mips);
	}

	@Override
	public GpuTexture createTexture(@Nullable String label, int usage, TextureFormat format, int w, int h, int layers, int mips) {
		return new Dx12Resources.Texture(usage, label, format, w, h, layers, mips);
	}

	@Override public GpuTextureView createTextureView(GpuTexture texture) {
		return new Dx12Resources.TextureView(texture, 0, texture.getMipLevels());
	}

	@Override public GpuTextureView createTextureView(GpuTexture texture, int baseMip, int mips) {
		return new Dx12Resources.TextureView(texture, baseMip, mips);
	}

	@Override
	public GpuBuffer createBuffer(@Nullable Supplier<String> label, int usage, long size) {
		return new Dx12Resources.Buffer(usage, size);
	}

	@Override
	public GpuBuffer createBuffer(@Nullable Supplier<String> label, int usage, ByteBuffer data) {
		Dx12Resources.Buffer buffer = new Dx12Resources.Buffer(usage, data.remaining());
		buffer.data.put(data.duplicate());
		return buffer;
	}

	@Override
	public CompiledRenderPipeline precompilePipeline(RenderPipeline pipeline, @Nullable ShaderSource shaderSource) {
		Dx12Resources.Pipeline existing = compiled.get(pipeline);
		if (existing != null) return existing;
		pipelines++;
		ShaderSource source = shaderSource != null ? shaderSource : defaultShaderSource;
		Dx12Resources.Pipeline result = new Dx12Resources.Pipeline(0L, pipeline.getLocation().toString(), Map.of(), Map.of(), pipeline.getVertexFormatMode());
		if (translatorBroken) {
			Dx12Mod.LOGGER.info("[DX12] pipeline #{}: {} (sin traducir)", pipelines, pipeline);
		} else {
			try {
				ShaderTranslator.Result r = ShaderTranslator.translate(pipeline, source);
				shadersOk++;
				String name = pipeline.getLocation().toString();
				long handle = Dx12Native.createPipeline(name, r.vertexHlsl(), r.fragmentHlsl(), vertexLayout(pipeline), pipelineState(pipeline));
				if (handle == 0L) {
					nativeFailed++;
					Dx12Mod.LOGGER.warn("[DX12] pipeline #{}: {} -> D3D12 FALLO: {}", pipelines, name, Dx12Native.lastError());
				} else {
					nativeOk++;
					result = new Dx12Resources.Pipeline(handle, name, r.uboBindings(), r.samplerBindings(), pipeline.getVertexFormatMode());
					Dx12Mod.LOGGER.info("[DX12] pipeline #{}: {} -> listo", pipelines, name);
				}
			} catch (ShaderTranslator.TranslateException e) {
				shadersFailed++;
				Dx12Mod.LOGGER.warn("[DX12] pipeline #{}: {} -> FALLO: {}", pipelines, pipeline, e.getMessage());
			} catch (Throwable t) {
				// Dependencias ausentes, DLL de shaderc/spvc que no carga, API distinta...: no se rompe el juego.
				translatorBroken = true;
				Dx12Mod.LOGGER.error("[DX12] El traductor de shaders no esta disponible; se desactiva", t);
			}
		}
		compiled.put(pipeline, result);
		return result;
	}

	Dx12Resources.Pipeline pipelineFor(RenderPipeline pipeline) {
		return (Dx12Resources.Pipeline) precompilePipeline(pipeline, null);
	}

	private static int[] vertexLayout(RenderPipeline pipeline) {
		VertexFormat f = pipeline.getVertexFormat();
		java.util.List<VertexFormatElement> els = f.getElements();
		int[] a = new int[2 + els.size() * 4];
		a[0] = f.getVertexSize();
		a[1] = els.size();
		for (int i = 0; i < els.size(); i++) {
			VertexFormatElement e = els.get(i);
			a[2 + i * 4] = e.type().ordinal();
			a[3 + i * 4] = e.count();
			// GL normaliza color y normal; posicion/UV/genericos enteros no se normalizan
			a[4 + i * 4] = (e.usage() == VertexFormatElement.Usage.COLOR || e.usage() == VertexFormatElement.Usage.NORMAL) ? 1 : 0;
			a[5 + i * 4] = f.getOffset(e);
		}
		return a;
	}

	private static int[] pipelineState(RenderPipeline p) {
		int[] st = new int[15];
		st[0] = switch (p.getDepthTestFunction()) {
			case NO_DEPTH_TEST -> 0;
			case EQUAL_DEPTH_TEST -> 1;
			case LEQUAL_DEPTH_TEST -> 2;
			case LESS_DEPTH_TEST -> 3;
			case GREATER_DEPTH_TEST -> 4;
		};
		st[1] = p.isWriteDepth() ? 1 : 0;
		st[2] = !p.isCull() || NO_CULL ? 0 : (FLIP_CULL ? 2 : 1);  // 0 ninguno, 1 traseras, 2 delanteras
		var blend = p.getBlendFunction();
		if (blend.isPresent()) {
			BlendFunction b = blend.get();
			st[3] = 1;
			st[4] = src(b.sourceColor(), false);
			st[5] = dst(b.destColor(), false);
			st[6] = src(b.sourceAlpha(), true);
			st[7] = dst(b.destAlpha(), true);
		}
		st[8] = (p.isWriteColor() ? 7 : 0) | (p.isWriteAlpha() ? 8 : 0);
		st[9] = p.getPolygonMode() == com.mojang.blaze3d.platform.PolygonMode.WIREFRAME ? 1 : 0;
		// tipo de topologia D3D12: 1 punto, 2 linea, 3 triangulo; topologia D3D: 1 puntos, 2 lineas, 3 tira de lineas, 4 triangulos, 5 tira de triangulos
		switch (p.getVertexFormatMode()) {
			case POINTS -> { st[10] = 1; st[11] = 1; }
			case DEBUG_LINES -> { st[10] = 2; st[11] = 2; }
			case DEBUG_LINE_STRIP -> { st[10] = 2; st[11] = 3; }
			case TRIANGLE_STRIP -> { st[10] = 3; st[11] = 5; }
			default -> { st[10] = 3; st[11] = 4; } // TRIANGLES, QUADS y LINES (ambos con indices de triangulos), TRIANGLE_FAN (no soportado)
		}
		st[12] = Float.floatToRawIntBits(p.getDepthBiasConstant());
		st[13] = Float.floatToRawIntBits(p.getDepthBiasScaleFactor());
		if (NO_DEPTH) st[0] = 0;
		st[14] = st[0] == 0 ? 0 : 1;
		return st;
	}

	// valores de D3D12_BLEND
	private static int src(SourceFactor f, boolean alpha) {
		return switch (f) {
			case ZERO -> 1;
			case ONE -> 2;
			case SRC_COLOR -> alpha ? 5 : 3;
			case ONE_MINUS_SRC_COLOR -> alpha ? 6 : 4;
			case SRC_ALPHA -> 5;
			case ONE_MINUS_SRC_ALPHA -> 6;
			case DST_ALPHA -> 7;
			case ONE_MINUS_DST_ALPHA -> 8;
			case DST_COLOR -> alpha ? 7 : 9;
			case ONE_MINUS_DST_COLOR -> alpha ? 8 : 10;
			case SRC_ALPHA_SATURATE -> 11;
			case CONSTANT_COLOR, CONSTANT_ALPHA -> 14;
			case ONE_MINUS_CONSTANT_COLOR, ONE_MINUS_CONSTANT_ALPHA -> 15;
		};
	}

	private static int dst(DestFactor f, boolean alpha) {
		return switch (f) {
			case ZERO -> 1;
			case ONE -> 2;
			case SRC_COLOR -> alpha ? 5 : 3;
			case ONE_MINUS_SRC_COLOR -> alpha ? 6 : 4;
			case SRC_ALPHA -> 5;
			case ONE_MINUS_SRC_ALPHA -> 6;
			case DST_ALPHA -> 7;
			case ONE_MINUS_DST_ALPHA -> 8;
			case DST_COLOR -> alpha ? 7 : 9;
			case ONE_MINUS_DST_COLOR -> alpha ? 8 : 10;
			case CONSTANT_COLOR, CONSTANT_ALPHA -> 14;
			case ONE_MINUS_CONSTANT_COLOR, ONE_MINUS_CONSTANT_ALPHA -> 15;
		};
	}

	@Override
	public void clearPipelineCache() {
		for (Dx12Resources.Pipeline p : compiled.values()) if (p.handle != 0L) Dx12Native.destroyPipeline(p.handle);
		compiled.clear();
	}

	@Override public String getImplementationInformation() { return "DirectX 12 (" + adapter + ")"; }
	@Override public List<String> getLastDebugMessages() { return List.of(); }
	@Override public boolean isDebuggingEnabled() { return false; }
	@Override public String getVendor() { return "Microsoft"; }
	@Override public String getBackendName() { return "DirectX 12"; }
	@Override public String getVersion() { return "D3D12"; }
	@Override public String getRenderer() { return adapter; }
	@Override public int getMaxTextureSize() { return 16384; }
	@Override public int getUniformOffsetAlignment() { return 256; }
	@Override public List<String> getEnabledExtensions() { return List.of(); }
	@Override public int getMaxSupportedAnisotropy() { return 1; }

	@Override
	public void close() {
		Dx12Mod.LOGGER.info("[DX12] Resumen: {}", Dx12Native.stats());
		Dx12Mod.LOGGER.info("[DX12] Shaders: {} traducidos, {} con fallo de traduccion; pipelines D3D12: {} OK, {} con fallo (HLSL en dx12mod/shaders)",
			shadersOk, shadersFailed, nativeOk, nativeFailed);
		Dx12RenderPass.logSummary();
		Dx12Native.shutdown();
	}
}
